
class Edge:

    def __init__(self, in_node, edge_count, out_node):
        self.in_node = in_node
        self.edge_count = edge_count
        self.out_node = out_node
